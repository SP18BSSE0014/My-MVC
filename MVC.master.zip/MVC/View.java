package project;

import java.sql.ResultSet;

public class View {
	public void viewData(ResultSet r, String field) {
		try {
			while(r.next()) {
				String data = r.getString(field);
				System.out.println(field + "=" + data);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void AllData(ResultSet r) {
		try {
			while(r.next()) {
				String employeeId = r.getString("EmployeeID");
				String firstName = r.getString("FirstName");
				String lastName = r.getString("LastName");
				String Gender = r.getString("Gender");
				String HiredDate = r.getString("HiredDate");
				int Salary = r.getInt("Salary");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());// TODO: handle exception
		}
	}

}
