package project;

import java.sql.SQLException;

public class MVCTest {

	public static void main(String[] args) throws SQLException {
		Controller cont = new Controller();
		cont.viewAllData();
		cont.viewData("FirstName", "abc");
	}
}
